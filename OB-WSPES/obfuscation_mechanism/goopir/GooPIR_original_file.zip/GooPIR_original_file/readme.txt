This file downlod from GooPIR website.

https://unescoprivacychair.urv.cat/goopir.php